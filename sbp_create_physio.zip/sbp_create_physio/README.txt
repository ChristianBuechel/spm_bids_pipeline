= = = Pipeline for physio regressor creation = = =

- the function sbp_create_physio can be integrated into do_em_all in the same way as the other preprocessing/noise creation functions.
- move all contents of 'utils' into the spm_bids_pipeline utils!

= INPUT =: 
all_sub_ids.

IMPORTANT: Your smr files need to be stored as such:
path.baseDir/physio/smr/sub-XX_ses-YY_physio.smr

= OPERATIONS (functions found in utils) =:
1. convert_physio_smr: converts raw SMR to mat-files that are readable for cleaning and regressor creation. via https://github.com/tjrantal/Spike-smr-reader
2. clean_physio: cleans mats (divide into runs, clean excess pulses / add pulses where necessary) and saves as BIDS-compatible run-wise tsv files with jsons in func dirs
3. create_tapas: Uses tapas toolbox to create txt file of 18 physiological noise regressors in func dirs of subjects.


= OUTPUTS =:
-BIDS-compatible run-wise tsv files of physiological data with jsons in func dir of each sub
-txt file of 18 physiological noise regressors in func dirs of each sub.
-info_physio mat file containing some info coming from tapas toolbox, in func dir of each sub


= REQUIREMENTS =:
1. SMR Reader (https://github.com/tjrantal/Spike-smr-reader)
	**NO DOWNLOAD NEEDED**
    all necessary functions are in utils!

2. TAPAS PhysIO Toolbox
	Download:
    **HAS TO BE DOWNLOADED**

    https://github.com/translationalneuromodeling/tapas/releases
    go to tapas_master and type tapas_init() in command line
    you need to do this only once. It will be set up for good in your spm12 after


CHANGES TO ANALYSIS:
in sbp_analyses, the following lines need to be changed:
line 391:   '.mat' extension needs to be changed to '.txt' extension:          physio_noise_f = char(spm_file(epifiles{run},'prefix','physio_','ext','.txt'));
line 396:   'physio_noise.physio' needs to be changed to 'physio_noise'        all_nuis{run} = [all_nuis{run} normit(physio_noise)];


	
